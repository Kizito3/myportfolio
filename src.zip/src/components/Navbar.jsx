export default function Navbar() {
  return <div>Navbar</div>;
}
