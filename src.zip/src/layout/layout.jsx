// layout/layout.jsx

import Footer from "../components/Footer";
import Navbar from "../components/Navbar";

export default function Layout({ children }) {
  return (
    <div>
      <Navbar />
      {children} {/* render children instead of Outlet */}
      <Footer />
    </div>
  );
}
