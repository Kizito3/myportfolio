import "./App.css";

function App() {
  return (
    <div>
      <h1 className="text-5xl">Hello from my portfolio</h1>
    </div>
  );
}

export default App;
